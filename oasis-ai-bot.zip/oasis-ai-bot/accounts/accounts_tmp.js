INPUT YOUR EMAIL HERE|INPUT YOUR PASSWORD HERE
// EX : bujanginam@gmail.com|Bujang1nam
// ** 1 Accounts for 1 Line **