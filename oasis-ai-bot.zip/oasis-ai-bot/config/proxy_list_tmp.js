http://username:password@hostname:port 
// 1 Proxy for 1 Provider